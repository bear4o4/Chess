#include<iostream>
#include "Gameflow.h"
#include <conio.h>
#include <Windows.h>
using namespace std;

int main() {
	Gameflow X;
	X.play();

	return 0;
}












