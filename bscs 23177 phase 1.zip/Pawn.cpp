#include "Pawn.h"

Pawn::Pawn(int _r, int _c, color _C, Board* _B) :Piece(_r,_c,_C,_B)
{

}
bool Pawn::IsLegalMove(int er, int ec) {
	return true;
}

void Pawn::Draw()
{
	cout << ((C == WHITE) ? 'P' : 'p');
}
