#include "Bishp.h"

Bishp::Bishp(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{
}

bool Bishp::IsLegalMove(int er, int ec)
{
	return false;
}

void Bishp::Draw()
{
	cout << ((C == WHITE) ? 'B' : 'b');
}

