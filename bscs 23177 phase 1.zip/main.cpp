#include<iostream>
#include "Gameflow.h"
using namespace std;

int main() {
	Gameflow X;
	X.play();

	return 0;
}