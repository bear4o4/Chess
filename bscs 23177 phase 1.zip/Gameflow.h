#pragma once
using namespace std;
#include<iostream>
#include"Board.h"
#include"Player.h"
#include"Piece.h"


class Gameflow
{
private:
	int sr, sc, er, ec;
	int turn;
	Player* Pps[2];
	Board* B;
public:
	Gameflow();
	void play();




};


