#pragma once
#include"Header.h"
#include"Piece.h"
#include"Pawn.h"
#include"Rook.h"
#include"King.h"
#include"Queen.h"
#include"Bishp.h"
#include"Knight.h"
using namespace std;
class Piece;
class Pawn;

class Board
{
protected:
	Piece*** Ps;

public:
	Board();
	//void INITboard();
	void PRINTboard();


};

