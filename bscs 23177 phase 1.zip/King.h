#pragma once
#include "Piece.h"
class King : public Piece
{
	//bool IsFirstMove;

public:
	King(int _r, int _c, color _C, Board* _B);
	virtual bool IsLegalMove(int er, int ec);
	virtual void Draw();
};