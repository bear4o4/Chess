#include "Gameflow.h"

Gameflow::Gameflow()
{
	Pps[0] = new Player("Hamza", BLACK);
	Pps[1] = new Player("Hamza2", WHITE);
	B = new Board();
	//turn = Pps[1];
}

void Gameflow::play()
{
	B->PRINTboard();

	/*do
	{
		
		do
		{
			do
			{
				do
				{

				} while (true);
			} while (true);
		} while (true);
	} while (true);*/
	

}
