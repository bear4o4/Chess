#include "Rook.h"

Rook::Rook(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{
}


bool Rook::IsLegalMove(int er, int ec) {
	return true;
}

void Rook::Draw()
{
	cout << ((C == WHITE) ? 'R' : 'r');
}