#pragma once
#include "Piece.h"
class Pawn : public Piece
{
	bool IsFirstMove;

public:
	Pawn(int _r,int _c,color _C,Board* _B);
	virtual bool IsLegalMove(int er, int ec);
	virtual void Draw();
};

