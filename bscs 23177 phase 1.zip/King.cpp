#include "King.h"

King::King(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{
}

bool King::IsLegalMove(int er, int ec)
{
	return false;
}

void King::Draw()
{
	cout << ((C == WHITE) ? 'K' : 'k');
}
