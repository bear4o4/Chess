#include "Knight.h"

Knight::Knight(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{

}
bool Knight::IsLegalMove(int er, int ec) {
	return true;
}

void Knight::Draw()
{
	cout << ((C == WHITE) ? 'N' : 'n');
}