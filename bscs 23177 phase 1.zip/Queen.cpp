#include "Queen.h"

Queen::Queen(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{
}


bool Queen::IsLegalMove(int er, int ec) {
	return true;
}

void Queen::Draw()
{
	cout << ((C == WHITE) ? 'Q' : 'q');
}