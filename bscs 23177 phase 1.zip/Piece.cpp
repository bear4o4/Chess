#include "Piece.h"

bool Piece::IsHorizontalMove(int sr, int sc, int er, int ec)
{
	return sr == er;
}

bool Piece::IsVerticalMove(int sr, int sc, int er, int ec)
{
	return sc == ec;
}

bool Piece::IsDiagonalMove(int sr, int sc, int er, int ec)
{
	return abs(sr - er) == abs(sc - ec);
}

bool Piece::IsHorizontalPathClear(int sr, int sc, int er, int ec)
{

	return false;
}

bool Piece::IsVertiaclPathClear(int sr, int sc, int er, int ec)
{
	return false;
}

bool Piece::IsDiagonalPathClear(int sr, int sc, int er, int ec)
{
	return false;
}

Piece::Piece(int _r, int _c, color _C, Board* _B)
{
	ri = _r;
	ci = _c;
	C = _C;
	B = _B;

}
