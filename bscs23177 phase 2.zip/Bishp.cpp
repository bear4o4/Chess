#include "Bishp.h"

Bishp::Bishp(int _r, int _c, color _C, Board* _B) :Piece(_r, _c, _C, _B)
{
	/*this->ri = _r;
	this->ci = _c;
	this->C = _C;
	this->B = _B;*/
}

bool Bishp::IsLegalMove(Board* B, int sr, int sc, int er, int ec)
{
	return IsDiagonalMove(sr, sc, er, ec) && IsDiagonalPathClear(B, sr, sc, er, ec);
}

void Bishp::Draw()
{
	cout << ((C == WHITE) ? 'B' : 'b');
}

