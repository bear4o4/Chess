#include "Pawn.h"

Pawn::Pawn(int _r, int _c, color _C, Board* _B) :Piece(_r,_c,_C,_B)
{
	/*this->ri = _r;
	this->ci = _c;
	this->C = _C;
	this->B = _B;*/
}
bool Pawn::IsLegalMove(Board* B, int sr, int sc, int er, int ec) {
	int changeinrow;
	changeinrow = abs(sr - er);

	if (getColor() == BLACK) {
		if (changeinrow == 2) {
			return IsVerticalMove(sr, sc, sr - 2, sc) && IsVertiaclPathClear(B, sr, sc, sr - 2, sc);
		}
		else if (changeinrow == 1) {
			return IsVerticalMove(sr, sc, sr - 1, sc) && IsVertiaclPathClear(B, sr, sc, sr - 1, sc);
		}
	}
	else if (getColor() == WHITE) {//oper
		if (changeinrow == 2) {
			return IsVerticalMove(sr, sc, sr+2, sc) && IsVertiaclPathClear(B, sr, sc, sr + 2, sc);
		}
		else if (changeinrow == 1) {
			return IsVerticalMove(sr, sc, sr + 1, sc) && IsVertiaclPathClear(B, sr, sc, sr + 1, sc);
		}
	}
	


}

void Pawn::Draw()
{
	cout << ((C == WHITE) ? 'P' : 'p');
}
