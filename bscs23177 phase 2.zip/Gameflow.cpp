#include "Gameflow.h"

Gameflow::Gameflow()
{
	Pps[0] = new Player("PLAYER 1", BLACK);
	Pps[1] = new Player("PLAYER 2", WHITE);
	B = new Board();
	turn = 0;
}

void Gameflow::play()
{
	B->PRINTboard();
	do{
		TurnMsg(Pps[turn]);
		do{
			do{
				do{
					SelectSRCPosition(sr, sc);
				} while (!IsValidSourceSelected(Pps[turn],sr,sc));

				SelectDESPosition(er, ec);
			} while (!IsValidDestinationSelected(Pps[turn],er,ec));

		} while (!IsLegalMove());

		UpdateBoard(sr,sc,er,ec);
		B->PRINTboard();
	} while (true);
}

void Gameflow::TurnMsg(Player* P)
{
	cout << endl;
	if (turn == 0) {//white
		//if (P->getColor() == 15 && P->getName() == "PLAYER 2") {
		cout << P->getName() << " TURN :" << endl;
		cout << "WHITE (above)" << endl;
		turn++;
	}
	else if (turn == 1) {
		//if (P->getColor() == 0 && P->getName() == "PLAYER 1") {
		cout << P->getName() << " TURN :" << endl;
		cout << "BLACK (below)" << endl;
		turn--;
	}
	cout << endl;
}
void Gameflow::SelectSRCPosition(int& sr, int& sc)
{
	cout << "ENTER PIECE SOURCE COORDINATES :" << endl;
	cin >> sr >> sc;
}
void Gameflow::SelectDESPosition(int& er, int& ec) {
	cout << "ENTER PIECE DESTINATION COORDINATES :" << endl;
	cin >> er >> ec;
}
bool Gameflow::IsValidSourceSelected(Player* Pps, int r, int c)
{
	if (r >= 0 && r < 8 && c >= 0 && c < 8) {
		return true;
	}
	/*Piece* p = B->getPiece(r, c);
	return p != nullptr&& p->getColor() == Pps->getColor();*/
}
bool Gameflow::IsValidDestinationSelected(Player* Pps, int r, int c)
{
	if (r >= 0 && r < 8 && c >= 0 && c < 8) {
		return true;
	}
	//Piece* p = B->getPiece(r, c);
	//return p != nullptr; //&& p->getColor() != Pps->getColor();
}
bool Gameflow::IsLegalMove()
{
	if (B->getPiece(sr, sc)->IsLegalMove(B, sr, sc, er, ec)==true) {
		return true;
	}
	else {
		return false;
	}
}
void Gameflow::UpdateBoard(int &sr,int &sc,int &er,int &ec)
{
	B->setPiece(sr, sc, er, ec);
}


