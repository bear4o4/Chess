#pragma once
#include "Piece.h"
class Bishp : public Piece
{
	bool IsFirstMove;

public:
	Bishp(int _r, int _c, color _C, Board* _B);
	virtual bool IsLegalMove(Board* B, int sr, int sc, int er, int ec);
	virtual void Draw();
};